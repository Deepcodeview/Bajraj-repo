import prisma from "../../config/database.js";

const COOLDOWN_SECONDS = parseInt(process.env.ATTENDANCE_COOLDOWN_SECONDS || "60", 10);

export async function processAiAttendanceEvent(payload) {
  const { eventId, cameraId, employeeId, eventType, confidence, timestamp } = payload;
  const eventTimestamp = new Date(timestamp);

  const camera = await prisma.cameras.findFirst({
    where: { camera_code: cameraId, status: "ACTIVE" },
  });
  if (!camera) {
    const exists = await prisma.cameras.findFirst({ where: { camera_code: cameraId } });
    const reason = exists ? "CAMERA_INACTIVE" : "CAMERA_NOT_FOUND";
    console.log(`[AI_ATTENDANCE] camera=${cameraId} rejected reason=${reason}`);
    return { status: 404, body: { success: false, reason, message: reason === "CAMERA_NOT_FOUND" ? "Camera not found" : "Camera is not active" } };
  }

  const { organization_id: organizationId, store_id: storeId, id: cameraDbId } = camera;

  const employee = await prisma.employees.findFirst({
    where: { employee_code: employeeId, organization_id: organizationId },
  });
  if (!employee) {
    console.log(`[AI_ATTENDANCE] camera=${cameraId} employeeCode=${employeeId} reason=EMPLOYEE_NOT_FOUND`);
    return { status: 404, body: { success: false, reason: "EMPLOYEE_NOT_FOUND", message: "Employee not found" } };
  }
  if (employee.status !== "ACTIVE") {
    console.log(`[AI_ATTENDANCE] camera=${cameraId} employeeCode=${employeeId} reason=EMPLOYEE_INACTIVE`);
    return { status: 422, body: { success: false, reason: "EMPLOYEE_INACTIVE", message: "Employee is not active" } };
  }

  console.log(`[AI_ATTENDANCE] camera=${cameraId} employeeId=${employee.id} confidence=${confidence} event=${eventType}`);

  try {
    const result = await prisma.$transaction(async (tx) => {

      const existingEvent = await tx.ai_events.findFirst({
        where: { organization_id: organizationId, event_id: eventId },
      });
      if (existingEvent) {
        console.log(`[AI_ATTENDANCE] eventId=${eventId} reason=DUPLICATE_EVENT`);
        return { processed: false, reason: "DUPLICATE_EVENT" };
      }

      const cooldownFrom = new Date(eventTimestamp.getTime() - COOLDOWN_SECONDS * 1000);
      const recentEvent = await tx.ai_events.findFirst({
        where: {
          organization_id: organizationId,
          employee_id: employee.id,
          camera_id: cameraDbId,
          event_timestamp: { gte: cooldownFrom },
          processing_status: "PROCESSED",
        },
        orderBy: { event_timestamp: "desc" },
      });
      if (recentEvent) {
        console.log(`[AI_ATTENDANCE] employeeId=${employee.id} reason=COOLDOWN`);
        return { processed: false, reason: "COOLDOWN" };
      }

      const openSession = await tx.employee_sessions.findFirst({
        where: {
          employee_id: employee.id,
          organization_id: organizationId,
          status: "ACTIVE",
          session_end: null,
        },
        orderBy: { session_start: "desc" },
      });

      let attendanceAction;
      let session;

      if (!openSession) {
        session = await tx.employee_sessions.create({
          data: {
            organization_id: organizationId,
            employee_id: employee.id,
            store_id: storeId,
            session_start: eventTimestamp,
            session_end: null,
            status: "ACTIVE",
          },
        });
        attendanceAction = "IN";
        console.log(`[AI_ATTENDANCE] employeeId=${employee.id} action=IN sessionId=${session.id}`);
      } else {
        session = await tx.employee_sessions.update({
          where: { id: openSession.id },
          data: {
            session_end: eventTimestamp,
            status: "COMPLETED",
            updated_at: new Date(),
          },
        });
        attendanceAction = "OUT";
        console.log(`[AI_ATTENDANCE] employeeId=${employee.id} action=OUT sessionId=${session.id}`);
      }

      await tx.ai_events.create({
        data: {
          organization_id: organizationId,
          store_id: storeId,
          camera_id: cameraDbId,
          employee_id: employee.id,
          employee_session_id: session.id,
          event_id: eventId,
          event_type: eventType,
          confidence: confidence,
          event_timestamp: eventTimestamp,
          subject_id: employeeId,
          processing_status: "PROCESSED",
          raw_payload: payload,
          normalized_payload: {
            attendanceAction,
            employeeCode: employee.employee_code,
            cameraCode: cameraId,
            organizationId,
            storeId,
            sessionId: session.id,
          },
        },
      });

      return { processed: true, attendanceAction, session };
    });

    if (!result.processed) {
      return { status: 200, body: { success: true, processed: false, reason: result.reason } };
    }

    return {
      status: 200,
      body: {
        success: true,
        processed: true,
        attendanceAction: result.attendanceAction,
        employee: {
          id: employee.id,
          employeeCode: employee.employee_code,
          name: `${employee.first_name}${employee.last_name ? " " + employee.last_name : ""}`.trim(),
        },
        camera: { cameraCode: cameraId },
        sessionId: result.session.id,
        eventId,
      },
    };
  } catch (error) {
    if (error.code === "P2002") {
      console.log(`[AI_ATTENDANCE] eventId=${eventId} reason=DUPLICATE_EVENT (race)`);
      return { status: 200, body: { success: true, processed: false, reason: "DUPLICATE_EVENT" } };
    }
    console.error(`[AI_ATTENDANCE] transaction failed eventId=${eventId}`, error.message);
    throw error;
  }
}
