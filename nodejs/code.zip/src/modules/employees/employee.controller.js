import { createEmployee, getEmployees, getEmployeeById, updateEmployee, deleteEmployee } from "./employee.service.js";

export async function createEmployeeController(req, res) {
	try {
		const employee = await createEmployee(req.user.organizationId, req.body);
		return res.status(201).json({ success: true, message: "Employee created successfully", data: employee });
	} catch (error) {
		return res.status(400).json({ success: false, message: error.message });
	}
}

export async function getEmployeesController(req, res) {
	try {
		const employees = await getEmployees(req.user.organizationId);
		return res.status(200).json({ success: true, data: employees });
	} catch (error) {
		return res.status(500).json({ success: false, message: error.message });
	}
}

export async function getEmployeeByIdController(req, res) {
	try {
		const employee = await getEmployeeById(req.user.organizationId, req.params.id);
		return res.status(200).json({ success: true, data: employee });
	} catch (error) {
		return res.status(404).json({ success: false, message: error.message });
	}
}

export async function updateEmployeeController(req, res) {
	try {
		const employee = await updateEmployee(req.user.organizationId, req.params.id, req.body);
		return res.status(200).json({ success: true, message: "Employee updated successfully", data: employee });
	} catch (error) {
		return res.status(400).json({ success: false, message: error.message });
	}
}

export async function deleteEmployeeController(req, res) {
	try {
		await deleteEmployee(req.user.organizationId, req.params.id);
		return res.status(200).json({ success: true, message: "Employee deleted successfully" });
	} catch (error) {
		return res.status(404).json({ success: false, message: error.message });
	}
}
