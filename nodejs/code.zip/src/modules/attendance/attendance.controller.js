import { processAiAttendanceEvent } from "./attendance.service.js";

export async function aiEventController(req, res) {
  try {
    const result = await processAiAttendanceEvent(req.body);
    return res.status(result.status).json(result.body);
  } catch (error) {
    console.error("[AI_ATTENDANCE] Unhandled error:", error.message);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
}
