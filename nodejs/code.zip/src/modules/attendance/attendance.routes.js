import express from "express";
import { authenticateAiService } from "../../middleware/auth.middleware.js";
import { validateAiEvent } from "./attendance.validation.js";
import { aiEventController } from "./attendance.controller.js";

const router = express.Router();

router.post("/ai-event", authenticateAiService, validateAiEvent, aiEventController);

export default router;
